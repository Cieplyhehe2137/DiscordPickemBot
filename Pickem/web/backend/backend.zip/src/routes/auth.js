import express from "express";

const router = express.Router();

router.get("/test", (req, res) => {
    res.json({ ok: true, route: "auth works" });
});

export default router;