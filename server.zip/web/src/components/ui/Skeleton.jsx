export default function Skeleton({
  className = ''
}) {
  return (
    <div
      className={`animate-pulse rounded-2xl bg-white/5 ${className}`}
    />
  );
}