/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: active_panels
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `active_panels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phase` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `reminded` tinyint DEFAULT NULL,
  `closed` tinyint DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `stage` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stage_key` varchar(50) COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS (ifnull(`stage`, _utf8mb4 '')) STORED,
  `match_deadline` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_phase_stagekey_channel` (`phase`, `stage_key`, `channel_id`),
  KEY `idx_active_panels_lookup` (
  `guild_id`,
  `phase`,
  `stage`,
  `active`,
  `closed`,
  `deadline`
  )
) ENGINE = InnoDB AUTO_INCREMENT = 577 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: admin_logs
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `admin_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stage` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: archive_files
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `archive_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `path` varchar(512) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_guild` (`guild_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: community_stats_posts
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `community_stats_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(64) NOT NULL,
  `match_id` int NOT NULL,
  `stats_type` varchar(64) NOT NULL,
  `posted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_stats_post` (`guild_id`, `match_id`, `stats_type`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: doubleelim_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `doubleelim_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upper_final_a` text COLLATE utf8mb4_unicode_ci,
  `lower_final_a` text COLLATE utf8mb4_unicode_ci,
  `upper_final_b` text COLLATE utf8mb4_unicode_ci,
  `lower_final_b` text COLLATE utf8mb4_unicode_ci,
  `user_id` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint DEFAULT '0',
  `displayname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_doubleelim_prediction` (`guild_id`, `event_id`, `user_id`),
  KEY `idx_doubleelim_predictions_user_time` (`user_id`, `submitted_at`)
) ENGINE = InnoDB AUTO_INCREMENT = 83 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: doubleelim_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `doubleelim_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `upper_final_a` text COLLATE utf8mb4_unicode_ci,
  `lower_final_a` text COLLATE utf8mb4_unicode_ci,
  `upper_final_b` text COLLATE utf8mb4_unicode_ci,
  `lower_final_b` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_doubleelim_results_event` (`guild_id`, `event_id`),
  KEY `idx_doubleelim_results_active_id` (`active`, `id`),
  KEY `idx_doubleelim_results_event_active` (`guild_id`, `event_id`, `active`)
) ENGINE = InnoDB AUTO_INCREMENT = 5 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: doubleelim_scores
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `doubleelim_scores` (
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int DEFAULT NULL,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `displayname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_doubleelim_scores_scope` (`guild_id`, `event_id`, `user_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 1475 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: events
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('UPCOMING', 'OPEN', 'CLOSED', 'FINISHED') DEFAULT 'UPCOMING',
  `is_archived` tinyint(1) DEFAULT '0',
  `deadline` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `phase` varchar(50) DEFAULT 'SWISS_STAGE_1',
  `is_open` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_guild_slug` (`guild_id`, `slug`)
) ENGINE = InnoDB AUTO_INCREMENT = 42 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: leaderboard
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `leaderboard` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) NOT NULL,
  `event_id` int NOT NULL,
  `user_id` varchar(32) NOT NULL,
  `total_points` int NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_entry` (`guild_id`, `event_id`, `user_id`),
  KEY `idx_event` (`event_id`),
  KEY `idx_guild` (`guild_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 51926 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: match_map_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `match_map_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `match_id` int NOT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `user_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `map_no` tinyint NOT NULL,
  `pred_exact_a` int DEFAULT NULL,
  `pred_exact_b` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pred_map` (`match_id`, `user_id`, `map_no`)
) ENGINE = InnoDB AUTO_INCREMENT = 31320 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: match_map_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `match_map_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `match_id` int NOT NULL,
  `map_no` tinyint NOT NULL,
  `exact_a` int DEFAULT NULL,
  `exact_b` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_match_map` (`match_id`, `map_no`)
) ENGINE = InnoDB AUTO_INCREMENT = 578 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: match_points
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `match_points` (
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_id` int NOT NULL,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` tinyint NOT NULL,
  `computed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `source` enum('series', 'map') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'series',
  `event_id` int NOT NULL,
  PRIMARY KEY (`match_id`, `user_id`, `source`),
  UNIQUE KEY `uniq_match_points_src` (`guild_id`, `match_id`, `user_id`, `source`),
  CONSTRAINT `fk_pts_match` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: match_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `match_predictions` (
  `match_id` int NOT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` int NOT NULL,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pred_a` tinyint NOT NULL,
  `pred_b` tinyint NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pred_exact_a` int DEFAULT NULL,
  `pred_exact_b` int DEFAULT NULL,
  PRIMARY KEY (`match_id`, `user_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_match_predictions_match` (`match_id`),
  CONSTRAINT `fk_pred_match` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: match_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `match_results` (
  `match_id` int NOT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `res_a` int DEFAULT NULL,
  `res_b` int DEFAULT NULL,
  `finished_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exact_a` int DEFAULT NULL,
  `exact_b` int DEFAULT NULL,
  PRIMARY KEY (`match_id`),
  UNIQUE KEY `uniq_match_results_match` (`match_id`),
  CONSTRAINT `fk_res_match` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: matches
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `matches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phase` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_no` int DEFAULT NULL,
  `team_a` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_b` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `best_of` tinyint NOT NULL DEFAULT '3',
  `start_time_utc` datetime DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `panel_channel_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `panel_message_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_matches_scope` (`guild_id`, `event_id`, `phase`, `match_no`),
  KEY `idx_matches_lockwatch` (`is_locked`, `start_time_utc`),
  KEY `idx_matches_panel` (`panel_channel_id`, `panel_message_id`),
  KEY `fk_matches_event` (`event_id`),
  CONSTRAINT `fk_matches_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 448 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: mvp_candidates
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `mvp_candidates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(64) NOT NULL,
  `event_id` int NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `team_name` varchar(100) DEFAULT NULL,
  `image_url` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mvp_candidates_active` (`guild_id`, `is_active`),
  KEY `idx_mvp_candidates_event` (`guild_id`, `event_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 115 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: mvp_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `mvp_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(64) NOT NULL,
  `event_id` int NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `username` varchar(100) NOT NULL,
  `candidate_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_mvp_prediction_event` (`guild_id`, `event_id`, `user_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 226 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: mvp_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `mvp_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(64) NOT NULL,
  `event_id` int NOT NULL,
  `candidate_id` int NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_mvp_result_event` (`guild_id`, `event_id`),
  KEY `idx_mvp_results_event` (`guild_id`, `event_id`),
  KEY `idx_mvp_results_active` (`guild_id`, `event_id`, `active`)
) ENGINE = InnoDB AUTO_INCREMENT = 7 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: mvp_scores
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `mvp_scores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(64) NOT NULL,
  `event_id` int NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `displayname` varchar(100) NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mvp_scores_user` (`guild_id`, `event_id`, `user_id`),
  KEY `idx_mvp_scores_event` (`guild_id`, `event_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 301 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: phase_schedule_state
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `phase_schedule_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(64) NOT NULL,
  `event_id` int DEFAULT NULL,
  `phase` varchar(64) NOT NULL,
  `schedule_complete` tinyint(1) NOT NULL DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_phase_schedule` (`guild_id`, `event_id`, `phase`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: playin_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `playin_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teams` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` datetime DEFAULT NULL,
  `user_id` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint DEFAULT '0',
  `displayname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_playin_prediction` (`guild_id`, `event_id`, `user_id`),
  KEY `idx_playin_predictions_active` (`active`)
) ENGINE = InnoDB AUTO_INCREMENT = 446 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: playin_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `playin_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `correct_teams` text COLLATE utf8mb4_unicode_ci,
  `active` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_guild_result` (`guild_id`),
  KEY `idx_playin_results_active` (`active`)
) ENGINE = InnoDB AUTO_INCREMENT = 4 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: playin_scores
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `playin_scores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int DEFAULT NULL,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_playin_scores_scope` (`guild_id`, `event_id`, `user_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 13482 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: playoffs_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `playoffs_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semifinalists` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `finalists` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `winner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `third_place_winner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint DEFAULT '0',
  `displayname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `submitted_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_playoffs_prediction` (`guild_id`, `event_id`, `user_id`),
  KEY `idx_playoffs_predictions_active` (`active`)
) ENGINE = InnoDB AUTO_INCREMENT = 1342 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: playoffs_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `playoffs_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `correct_semifinalists` text COLLATE utf8mb4_unicode_ci,
  `correct_finalists` text COLLATE utf8mb4_unicode_ci,
  `correct_winner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct_third_place_winner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `active` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_playoffs_results_event` (`guild_id`, `event_id`),
  KEY `idx_playoffs_results_active_id` (`active`, `id`)
) ENGINE = InnoDB AUTO_INCREMENT = 37 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: playoffs_scores
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `playoffs_scores` (
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int DEFAULT NULL,
  `score` int DEFAULT NULL,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `displayname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_playoffs_scores_scope` (`guild_id`, `event_id`, `user_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 4178 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: swiss_predictions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `swiss_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pick_3_0` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pick_0_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `advancing` text COLLATE utf8mb4_unicode_ci,
  `active` tinyint DEFAULT '0',
  `submitted_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `stage` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_swiss_prediction` (`guild_id`, `event_id`, `user_id`, `stage`),
  KEY `idx_swiss_predictions_stage` (`stage`),
  KEY `idx_swiss_event` (`event_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 5181 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: swiss_results
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `swiss_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` int NOT NULL,
  `correct_3_0` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct_0_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct_advancing` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `stage` enum('stage1', 'stage2', 'stage3') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_swiss_results_event_stage` (`guild_id`, `event_id`, `stage`),
  KEY `idx_swiss_results_active` (`active`)
) ENGINE = InnoDB AUTO_INCREMENT = 90 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: swiss_scores
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `swiss_scores` (
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int DEFAULT NULL,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `swiss_number` int DEFAULT NULL,
  `stage` enum('stage1', 'stage2', 'stage3') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `displayname` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `event_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_swiss_scores_scope` (`guild_id`, `event_id`, `user_id`, `stage`)
) ENGINE = InnoDB AUTO_INCREMENT = 62066 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: teams
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_guild_name` (`guild_id`, `name`),
  KEY `idx_guild_active` (`guild_id`, `active`),
  KEY `idx_guild_sort` (`guild_id`, `sort_order`)
) ENGINE = InnoDB AUTO_INCREMENT = 191 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: tournament_audit_log
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `tournament_audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `guild_id` varchar(32) NOT NULL,
  `actor_discord_id` varchar(32) NOT NULL,
  `action` varchar(32) NOT NULL,
  `old_value` varchar(64) DEFAULT NULL,
  `new_value` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_total_scores
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_total_scores` (
  `guild_id` varchar(32) NOT NULL,
  `user_id` varchar(32) NOT NULL,
  `displayname` varchar(255) DEFAULT NULL,
  `total_points` int NOT NULL DEFAULT '0',
  `swiss_points` int NOT NULL DEFAULT '0',
  `playoffs_points` int NOT NULL DEFAULT '0',
  `playin_points` int NOT NULL DEFAULT '0',
  `doubleelim_points` int NOT NULL DEFAULT '0',
  `match_points` int NOT NULL DEFAULT '0',
  `correct_series` int NOT NULL DEFAULT '0',
  `correct_maps` int NOT NULL DEFAULT '0',
  `exact_maps` int NOT NULL DEFAULT '0',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`guild_id`, `user_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: active_panels
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: admin_logs
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: archive_files
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: community_stats_posts
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: doubleelim_predictions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: doubleelim_results
# ------------------------------------------------------------

INSERT INTO
  `doubleelim_results` (
    `id`,
    `guild_id`,
    `event_id`,
    `upper_final_a`,
    `lower_final_a`,
    `upper_final_b`,
    `lower_final_b`,
    `created_at`,
    `active`
  )
VALUES
  (
    4,
    '1321222990465073224',
    41,
    'TEST1, TEST2',
    'TEST3, GESGSEG',
    'XCVXCVZ, SDGSDGS',
    'SA23G23, 23G32G32G',
    '2026-07-03 16:01:35',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: doubleelim_scores
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: events
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: leaderboard
# ------------------------------------------------------------

INSERT INTO
  `leaderboard` (
    `id`,
    `guild_id`,
    `event_id`,
    `user_id`,
    `total_points`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    328,
    '1321222990465073224',
    28,
    '461851082570596352',
    10,
    '2026-05-19 11:24:31',
    '2026-05-19 11:24:31'
  );
INSERT INTO
  `leaderboard` (
    `id`,
    `guild_id`,
    `event_id`,
    `user_id`,
    `total_points`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    49776,
    '1321222990465073224',
    40,
    '461851082570596352',
    4,
    '2026-06-22 08:33:42',
    '2026-06-22 08:33:42'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: match_map_predictions
# ------------------------------------------------------------

INSERT INTO
  `match_map_predictions` (
    `id`,
    `match_id`,
    `guild_id`,
    `event_id`,
    `user_id`,
    `map_no`,
    `pred_exact_a`,
    `pred_exact_b`,
    `updated_at`
  )
VALUES
  (
    10349,
    331,
    '1321222990465073224',
    NULL,
    '461851082570596352',
    1,
    13,
    0,
    '2026-05-18 22:07:59'
  );
INSERT INTO
  `match_map_predictions` (
    `id`,
    `match_id`,
    `guild_id`,
    `event_id`,
    `user_id`,
    `map_no`,
    `pred_exact_a`,
    `pred_exact_b`,
    `updated_at`
  )
VALUES
  (
    10350,
    331,
    '1321222990465073224',
    NULL,
    '461851082570596352',
    2,
    13,
    0,
    '2026-05-18 22:07:59'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: match_map_results
# ------------------------------------------------------------

INSERT INTO
  `match_map_results` (
    `id`,
    `match_id`,
    `map_no`,
    `exact_a`,
    `exact_b`,
    `created_at`,
    `updated_at`,
    `guild_id`,
    `event_id`
  )
VALUES
  (
    333,
    447,
    1,
    13,
    9,
    '2026-07-03 16:12:47',
    '2026-07-03 16:36:06',
    '1321222990465073224',
    41
  );
INSERT INTO
  `match_map_results` (
    `id`,
    `match_id`,
    `map_no`,
    `exact_a`,
    `exact_b`,
    `created_at`,
    `updated_at`,
    `guild_id`,
    `event_id`
  )
VALUES
  (
    334,
    447,
    2,
    11,
    13,
    '2026-07-03 16:12:47',
    '2026-07-03 16:36:06',
    '1321222990465073224',
    41
  );
INSERT INTO
  `match_map_results` (
    `id`,
    `match_id`,
    `map_no`,
    `exact_a`,
    `exact_b`,
    `created_at`,
    `updated_at`,
    `guild_id`,
    `event_id`
  )
VALUES
  (
    337,
    447,
    3,
    16,
    5,
    '2026-07-03 16:36:06',
    '2026-07-03 16:36:06',
    '1321222990465073224',
    41
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: match_points
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: match_predictions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: match_results
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: matches
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mvp_candidates
# ------------------------------------------------------------

INSERT INTO
  `mvp_candidates` (
    `id`,
    `guild_id`,
    `event_id`,
    `nickname`,
    `team_name`,
    `image_url`,
    `is_active`,
    `created_at`
  )
VALUES
  (
    113,
    '1321222990465073224',
    41,
    'PreviewMVP1',
    'TEST2',
    NULL,
    1,
    '2026-07-02 22:37:07'
  );
INSERT INTO
  `mvp_candidates` (
    `id`,
    `guild_id`,
    `event_id`,
    `nickname`,
    `team_name`,
    `image_url`,
    `is_active`,
    `created_at`
  )
VALUES
  (
    114,
    '1321222990465073224',
    41,
    'PreviewMVP2',
    'TEST3',
    NULL,
    1,
    '2026-07-02 22:37:07'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mvp_predictions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mvp_results
# ------------------------------------------------------------

INSERT INTO
  `mvp_results` (
    `id`,
    `guild_id`,
    `event_id`,
    `candidate_id`,
    `active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    5,
    '1321222990465073224',
    41,
    113,
    1,
    '2026-07-02 22:37:39',
    '2026-07-02 22:37:39'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mvp_scores
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: phase_schedule_state
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: playin_predictions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: playin_results
# ------------------------------------------------------------

INSERT INTO
  `playin_results` (
    `id`,
    `guild_id`,
    `event_id`,
    `correct_teams`,
    `active`
  )
VALUES
  (
    3,
    '1321222990465073224',
    41,
    'TEST1, TEST2, TEST3, GESGSEG, XCVXCVZ, SDGSDGS, SA23G23, 23G32G32G',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: playin_scores
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: playoffs_predictions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: playoffs_results
# ------------------------------------------------------------

INSERT INTO
  `playoffs_results` (
    `id`,
    `guild_id`,
    `event_id`,
    `correct_semifinalists`,
    `correct_finalists`,
    `correct_winner`,
    `correct_third_place_winner`,
    `created_at`,
    `active`
  )
VALUES
  (
    32,
    '1321222990465073224',
    41,
    'TEST1, TEST2, TEST3, GESGSEG',
    'TEST1, TEST2',
    'TEST1',
    'TEST3',
    NULL,
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: playoffs_scores
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: swiss_predictions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: swiss_results
# ------------------------------------------------------------

INSERT INTO
  `swiss_results` (
    `id`,
    `guild_id`,
    `event_id`,
    `correct_3_0`,
    `correct_0_3`,
    `correct_advancing`,
    `created_at`,
    `stage`,
    `active`
  )
VALUES
  (
    76,
    '1321222990465073224',
    41,
    'TEST2, TEST1',
    '',
    '',
    NULL,
    'stage1',
    1
  );
INSERT INTO
  `swiss_results` (
    `id`,
    `guild_id`,
    `event_id`,
    `correct_3_0`,
    `correct_0_3`,
    `correct_advancing`,
    `created_at`,
    `stage`,
    `active`
  )
VALUES
  (
    77,
    '1321222990465073224',
    41,
    '',
    '',
    'TEST1, TEST2, TEST3, GESGSEG',
    NULL,
    'stage2',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: swiss_scores
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: teams
# ------------------------------------------------------------

INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    185,
    '1321222990465073224',
    '23G32G32G',
    NULL,
    NULL,
    1,
    8,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    186,
    '1321222990465073224',
    'fasafasfa',
    NULL,
    NULL,
    1,
    9,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    181,
    '1321222990465073224',
    'GESGSEG',
    NULL,
    NULL,
    1,
    4,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    184,
    '1321222990465073224',
    'SA23G23',
    NULL,
    NULL,
    1,
    7,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    183,
    '1321222990465073224',
    'SDGSDGS',
    NULL,
    NULL,
    1,
    6,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    178,
    '1321222990465073224',
    'TEST1',
    NULL,
    NULL,
    1,
    1,
    '2026-07-03 16:37:17',
    '2026-07-30 19:43:40'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    179,
    '1321222990465073224',
    'TEST2',
    NULL,
    NULL,
    1,
    2,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    180,
    '1321222990465073224',
    'TEST3',
    NULL,
    NULL,
    1,
    3,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    182,
    '1321222990465073224',
    'XCVXCVZ',
    NULL,
    NULL,
    1,
    5,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );
INSERT INTO
  `teams` (
    `id`,
    `guild_id`,
    `name`,
    `short_name`,
    `logo_url`,
    `active`,
    `sort_order`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    187,
    '1321222990465073224',
    'xzvxzvrwreve',
    NULL,
    NULL,
    1,
    10,
    '2026-07-03 16:37:17',
    '2026-07-03 16:37:17'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: tournament_audit_log
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_total_scores
# ------------------------------------------------------------


/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
